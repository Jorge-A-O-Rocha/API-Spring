package evento.fatec.api.area;
//import org.springfremework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AreaRepository extends JpaRepository<Area,Long>{

}
